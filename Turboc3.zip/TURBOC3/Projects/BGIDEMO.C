#include <graphics.h>
#include <conio.h>
#include <stdio.h>

int main(void)
{
    int gd = DETECT, gm;
    int err;

    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");
    err = graphresult();
    if (err != grOk) {
        printf("BGI error: %s\n", grapherrormsg(err));
        getch();
        return 1;
    }

    setbkcolor(BLACK);
    cleardevice();

    setcolor(CYAN);
    rectangle(80, 70, 560, 410);
    circle(320, 210, 90);

    setcolor(YELLOW);
    line(180, 330, 460, 330);
    outtextxy(230, 355, "graphics.h / BGI works!");
    outtextxy(220, 380, "Press any key to return");

    getch();
    closegraph();
    return 0;
}
